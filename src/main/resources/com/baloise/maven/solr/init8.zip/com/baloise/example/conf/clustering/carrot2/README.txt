An override location of the clustering algorithm's resources 
attribute definitions and lexical resources.

A directory from which to load algorithm-specific stop words,
stop labels and attribute definition XMLs. 

For an overview of Carrot2 lexical resources, see:
http://download.carrot2.org/head/manual/#chapter.lexical-resources

For an overview of Lingo3G lexical resources, see:
http://download.carrotsearch.com/lingo3g/manual/#chapter.lexical-resources
